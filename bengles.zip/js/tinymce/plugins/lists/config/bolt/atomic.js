configure({
  configs: [
    './prod.js'
  ]
});